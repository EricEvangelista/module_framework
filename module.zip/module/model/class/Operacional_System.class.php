<?php
	# classe operacional do modulo
	class Operacional_System {

		private $url;
		private $path;

		public function __construct($index, $path){
			$this->index = $index;
			$this->path = $path;
		}

		public function call_class($input){
			# chamada de classes
			if(is_array($input)){
				foreach ($input as $key => $value) {
					include_once $this->path.'/model/class/'.$value.'.class.php';
				}

			}else{
				return false;
			}
		}

	}