<?php
	class DB_Engine extends Connect {

		#inserção de dados no banco
		public static function db_select($table,$data,$filter,$query){

		 	$pdo = parent::get_connect();

		 	if($table == null and $data == null and $filter == null and $query != null){
		 		$direct_query = $pdo->prepare($query);
		 		if($direct_query->execute()){
		 			return true;
		 		}else{
		 			return false;
		 		}

		 	}else{

		 		// dados
		 		if(isset($data) and $data != "" and is_array($data)){
		 			$dt = implode(',',$data);
		 		}else{
		 			$dt = "*";
		 		}

		 		// filtro
		 		if(isset($filter) and $filter != "" and is_array($filter)){
		 			$ft =" WHERE ";
		 			foreach ($filter as $key => $value) {
		 				$ft .= "$key = :$key AND ";
		 			}

		 			// retirando ultimo and
		 			$ft = substr($ft,0,-4);

		 		}else{
		 			$ft = "";
		 		}


		 		// query extra
		 		if(isset($query) and $query != "" and is_array($query)){
		 			$qx = " AND $query";
		 		}else{
		 			$qx = "";
		 		}

		 		$sql = "SELECT $dt FROM $table $ft $qx";


		 		//iniciando a query
		 		$db_select = $pdo->prepare($sql);

		 		// filtrando os valores
		 		foreach ($filter as $key => $value) {
		 			$filter[$key] = filter_var($value);
		 		}

		 		// setando os valores
		 		foreach ($filter as $key => $value) {
		 			$db_select->bindValue(":$key",$value, PDO::PARAM_STR);
		 		}

		 		if($db_select->execute()){
		 			$db_select = $db_select->fetchAll();
		 			return $db_select;
		 		}else{
		 			return false;
		 		}
		 	}

		} // ./ db_select

		public static function db_insert($table,$data,$extra){

			$pdo = parent::get_connect();
			if(isset($extra) and $extra != "" and $table == "" and $data != ""){
				// inserção dos dados via query direta
				$db_insert = $pdo->prepare($extra);
				if($db_insert->execute()){
					return $db_insert->lastInsertId();
				}else{
					return false;
				}

			}else{
				// inserção dos dados via metodo dinamico
				if($data != "" and is_array($data)){
					$fields = "(".implode(',',array_keys($data)).")";
					$values = "(:".implode(',:',array_keys($data)).")";
				}

				$sql = "INSERT INTO $table $fields VALUES $values";
				$db_insert = $pdo->prepare($sql);
				foreach ($data as $key => $value) {
					$db_insert->bindValue(":$key",$value, PDO::PARAM_STR);
				}

				if($db_insert->execute()){
					return $db_insert->lastInsertId();
				}else{
					return false;
				}
			}
		}
	}