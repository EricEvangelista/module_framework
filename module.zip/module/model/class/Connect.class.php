<?php
	# classe de conexão com o banco de dados
	class Connect {

		public static $conn;

		public static function get_connect(){
			try{
				self::$conn = new PDO("mysql:host=localhost;dbname=db_in9pdv","root","@harpia489", array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES UTF8'));
				self::$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				
				return self::$conn;

			}catch(PDOException $e){
				return $e->getCode();
			}
		}
	}