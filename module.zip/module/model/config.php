<?php
	/*
		arquivo principal de configuração
	*/

	$config['project'] = "module"; // nome do projeto,especificamente o nome da pasta do projeto
	$url['path'] = $_SERVER['DOCUMENT_ROOT']."/".$config['project']; // url de raiz do sistema,ultilizado em inclusões de arquivos
	$url['index'] = "http://".$_SERVER['SERVER_NAME']."/".$config['project']; // url de redirecionamentos do sistema,ultilizada nas demais possibilidades.
	
	date_default_timezone_set('America/Fortaleza'); // configurações de hora e data,para alterar para sua região,substitua a cidade do metodo.

	// exibição de erros
	ini_set('display_errors',1);
	ini_set('display_startup_erros',1);
	error_reporting(E_ALL);