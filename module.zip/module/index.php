<?php
	# raiz do sistema
	require_once 'model/config.php';
	require_once $url['path'].'/model/class/Operacional_System.class.php';
	$module = new Operacional_System($url['index'], $url['path']);
	$module->call_class(array('Connect','DB_Engine'));
	$db = new DB_Engine();

	// dados de teste
	$table = "tb_user";
	$data = array('user_name', 'user_lastname');
	$filter = array('user_id' => 1, 'user_name' => 'Eric');

	//$db::db_select('table',$data,$filter,null);
	$db::db_insert('tabela',array('nome' => 'eric', 'sobrenome' => 'evangelista','endereco' => 'avenida C'),null);
